from flask import (
    Blueprint, flash, g, redirect, render_template, request, session, url_for
)
from werkzeug.exceptions import abort

from rewards.auth import login_required
from rewards.db import get_db
import datetime

bp = Blueprint('points', __name__)
now = datetime.datetime.now()

@bp.route('/')
def index():
    return render_template('home/index.html')
	
@bp.route('/points/index')
@login_required
def plists():
      conn = get_db()
      db = conn.cursor()
      points = db.execute("SELECT p.*, u.FULL_NAME FROM  REM_ACCUM_POINTS p JOIN REM_USERS u ON p.user_id = u.id  ORDER BY p.AWARDED_AT DESC").fetchall()
      return render_template('points/index.html', rewards=points)


@bp.route('/points/create', methods=('GET', 'POST'))
@login_required
def create():
    
    if request.method == 'POST':
        usertype = request.form['usertype']
        POINTS_AWARDED = request.form['points']
        COMMENTS = request.form['comments']
        AWARDED_AT = datetime.date(now.year,now.month,now.day)
        error = None

        if not POINTS_AWARDED:
            error = 'Points is required.'

        if error is not None:
            flash(error)
        else:
            conn = get_db()
            db = conn.cursor()
            users = db.execute("SELECT ID FROM REM_USERS WHERE IS_ACTIVE = 1 and USER_TYPE = :USER_TYPE",
				[usertype]).fetchall()
            print (users)
            for user in users:
                USER_ID = user[0];
                db.execute("INSERT INTO REM_ACCUM_POINTS (USER_ID,POINTS_AWARDED,AWARDED_AT,COMMENTS) VALUES (:USER_ID,:POINTS_AWARDED,:AWARDED_AT,:COMMENTS)",
				[USER_ID,
                                 POINTS_AWARDED,
                                 AWARDED_AT,
                                 COMMENTS
                                 ])
            
            conn.commit()
            flash("Points added successfully to Employees!", 'success')
            return redirect(url_for('points.plists'))

    return render_template('points/create.html')


@bp.route('/points/dashboard')
@login_required
def dashboard():
        user_id = session.get('user_id')
        conn = get_db()
        db = conn.cursor()
        total_points_earned = db.execute("SELECT total_points, total_received,total_spend, ((total_points+total_received)-total_spend) as Total, (total_points + total_received) as total_earned FROM (SELECT NVL2(SUM(points_awarded), SUM(points_awarded), 0)   as total_points FROM REM_ACCUM_POINTS WHERE user_id = :USER_ID) T1 CROSS JOIN (SELECT NVL2(SUM(received_points), SUM(received_points),0) as total_received FROM REM_POINTS WHERE USER_ID_TO = :USER_ID) T2 CROSS JOIN (SELECT NVL2(SUM(RECEIVED_POINTS), SUM(RECEIVED_POINTS),0) as total_spend FROM REM_POINTS WHERE USER_ID_FROM = :USER_ID) T3", [user_id]).fetchone()
        return render_template('points/dashboard.html', points=total_points_earned)	
		
@bp.route('/points/earned')
@login_required
def earned():
        user_id = session.get('user_id')
        conn = get_db()
        db = conn.cursor()
        total_points_received = db.execute("SELECT * FROM  REM_ACCUM_POINTS  where USER_ID=:USER_ID   ORDER BY AWARDED_AT DESC",[user_id]).fetchall()
        total_points_earned = db.execute("SELECT * FROM  REM_POINTS  where USER_ID_TO=:USER_ID   ORDER BY RECEIVED_AT DESC",[user_id]).fetchall()
        total_points = db.execute("SELECT total_points, total_received  FROM (SELECT NVL2(SUM(points_awarded), SUM(points_awarded), 0)   as total_points FROM REM_ACCUM_POINTS WHERE user_id = :USER_ID) T1 CROSS JOIN (SELECT NVL2(SUM(received_points), SUM(received_points),0) as total_received FROM REM_POINTS WHERE USER_ID_TO = :USER_ID) T2", [user_id]).fetchone()
        return render_template('points/earnedhistory.html', points=total_points_received, colleagues = total_points_earned, total=total_points)
		
		
@bp.route('/points/spend', methods=('GET', 'POST'))
@login_required
def spend():
    USER_ID_FROM = session.get('user_id')
    usertype ='Employee'
    conn = get_db()
    db = conn.cursor()
    users = db.execute("SELECT ID, FULL_NAME, EMAIL FROM REM_USERS WHERE IS_ACTIVE = 1 and USER_TYPE = :USER_TYPE AND ID!=:ID ORDER BY FULL_NAME ASC",
				[usertype, USER_ID_FROM]).fetchall()
    total_points_earned = db.execute("SELECT total_points, total_received,total_spend, ((total_points+total_received)-total_spend) as Total FROM (SELECT NVL2(SUM(points_awarded), SUM(points_awarded), 0)   as total_points FROM REM_ACCUM_POINTS WHERE user_id = :USER_ID) T1 CROSS JOIN (SELECT NVL2(SUM(received_points), SUM(received_points),0) as total_received FROM REM_POINTS WHERE USER_ID_TO = :USER_ID) T2 CROSS JOIN (SELECT NVL2(SUM(RECEIVED_POINTS), SUM(RECEIVED_POINTS),0) as total_spend FROM REM_POINTS WHERE USER_ID_FROM = :USER_ID) T3", [USER_ID_FROM]).fetchone()
   
    if request.method == 'POST':
	
        USER_ID_TO = request.form['colleague']
        POINTS_AWARDED = request.form['points']
        COMMENTS = request.form['comments']
        AWARDED_AT = datetime.date(now.year,now.month,now.day)
        error = None

        if not POINTS_AWARDED:
            error = 'Points is required.'

        if error is not None:
            flash(error)
        else:
            
            db.execute("INSERT INTO REM_POINTS (USER_ID_FROM,USER_ID_TO,RECEIVED_POINTS,RECEIVED_AT,COMMENTS) VALUES (:USER_ID_FROM,:USER_ID_TO,:POINTS_AWARDED,:AWARDED_AT,:COMMENTS)",
				[USER_ID_FROM,USER_ID_TO,
                                 POINTS_AWARDED,
                                 AWARDED_AT,
                                 COMMENTS
                                 ])
            
            conn.commit()
            flash("Points send successfully to your Colleague!", 'success')
            return redirect(url_for('points.spend'))

    return render_template('points/spend.html', users=users, total_points_earned = total_points_earned)
	
@bp.route('/points/spent')
@login_required
def spent():
        user_id = session.get('user_id')
        conn = get_db()
        db = conn.cursor()
        
        total_points_spend = db.execute("SELECT * FROM  REM_POINTS  where USER_ID_FROM=:USER_ID   ORDER BY RECEIVED_AT DESC",[user_id]).fetchall()
        total_points = db.execute("SELECT total_spent  FROM  (SELECT NVL2(SUM(received_points), SUM(received_points),0) as total_spent FROM REM_POINTS WHERE USER_ID_FROM = :USER_ID) T2", [user_id]).fetchone()
        return render_template('points/spenthistory.html', points=total_points_spend, total=total_points)