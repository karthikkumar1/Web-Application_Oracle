import functools

from flask import (
    Blueprint, flash, g, redirect, render_template, request, session, url_for
)
from werkzeug.security import check_password_hash, generate_password_hash

from rewards.db import get_db
import datetime

bp = Blueprint('auth', __name__, url_prefix='/auth')
now = datetime.datetime.now()

def login_required(view):
    """View decorator that redirects anonymous users to the login page."""
    @functools.wraps(view)
    def wrapped_view(**kwargs):
        if g.user is None:
            return redirect(url_for('auth.login'))

        return view(**kwargs)

    return wrapped_view


@bp.before_app_request
def load_logged_in_user():
    """If a user id is stored in the session, load the user object from
    the database into ``g.user``."""
    user_id = session.get('user_id')

    if user_id is None:
        g.user = None
    else:
        conn = get_db()
        db = conn.cursor()
        g.user = db.execute("SELECT * FROM REM_USERS WHERE ID = :ID",
				[user_id]).fetchone()
        
@bp.route('/users')
@login_required
def users():
      conn = get_db()
      db = conn.cursor()
      users = db.execute("SELECT * FROM  REM_USERS  ORDER BY CREATED_AT DESC").fetchall()
      return render_template('auth/users.html', users=users)


@bp.route('/register', methods=('GET', 'POST'))
@login_required
def register():
    """Register a new user.

    Validates that the username is not already taken. Hashes the
    password for security.
    """
    if request.method == 'POST':
        FULL_NAME = request.form['fullname']
        EMAIL = request.form['email']
        USERNAME = request.form['username']
        GENDER = request.form['gender']
        EMP_ID = request.form['employeeid']
        ORGANIZATION = request.form['organization']
        USER_TYPE = request.form['usertype']
        PASSWORD = request.form['password']
        IS_ACTIVE = 1
        CREATED_AT=datetime.date(now.year,now.month,now.day)
        UPDATED_AT=datetime.date(now.year,now.month,now.day)

        conn = get_db()
        db = conn.cursor()
        error = None

        if not USERNAME:
            error = 'Username is required.'
        elif not PASSWORD:
            error = 'Password is required.'
        elif  db.execute("SELECT * FROM REM_USERS WHERE USERNAME = :USERNAME",
				[USERNAME]).fetchone() is not None:
            error = 'User {0} is already registered.'.format(USERNAME)

        if error is None:
            # the name is available, store it in the database and go to
            # the login page
           
            db.execute("INSERT INTO REM_USERS (FULL_NAME,EMAIL,USERNAME,GENDER,EMP_ID,ORGANIZATION,USER_TYPE, IS_ACTIVE,CREATED_AT,UPDATED_AT,PASSWORD) VALUES (:FULL_NAME,:EMAIL,:USERNAME,:GENDER,:EMP_ID,:ORGANIZATION,:USER_TYPE,: IS_ACTIVE,:CREATED_AT,:UPDATED_AT,:PASSWORD)",
				[FULL_NAME,
                                 EMAIL,
                                 USERNAME,
                                 GENDER,
                                 EMP_ID,
                                 ORGANIZATION,
                                 USER_TYPE,
                                 IS_ACTIVE,
                                 CREATED_AT,
                                 UPDATED_AT,
                                 generate_password_hash(PASSWORD)
                                 ])
            
            conn.commit()
            flash("Registered successfully!", 'success')
            return redirect(url_for('auth.users'))

        flash(error, 'error')

    return render_template('auth/register.html')

def get_user(id):
    conn = get_db()
    db = conn.cursor()
    user = db.execute("SELECT * FROM REM_USERS WHERE ID = :ID",
				[id]).fetchone()
    if user is None:
        abort(404, "User id {0} doesn't exist.".format(id))
    
    return user

@bp.route('/<int:id>/update', methods=('GET', 'POST'))
@login_required
def update(id):
    user = get_user(id)
    if request.method == 'POST':
        FULL_NAME = request.form['fullname']
        EMAIL = request.form['email']
        GENDER = request.form['gender']
        EMP_ID = request.form['employeeid']
        ORGANIZATION = request.form['organization']
        USER_TYPE = request.form['usertype']
        IS_ACTIVE = request.form['active']
        UPDATED_AT=datetime.date(now.year,now.month,now.day)
        conn = get_db()
        db = conn.cursor()
        db.execute("update  REM_USERS set FULL_NAME = :FULL_NAME ,EMAIL=:EMAIL,GENDER=:GENDER,EMP_ID=:EMP_ID,ORGANIZATION=:ORGANIZATION,USER_TYPE=:USER_TYPE, IS_ACTIVE=:IS_ACTIVE,UPDATED_AT=:UPDATED_AT where ID=:ID",
                                            [FULL_NAME,
                                             EMAIL,
                                             GENDER,
                                             EMP_ID,
                                             ORGANIZATION,
                                             USER_TYPE,
                                             IS_ACTIVE,
                                             UPDATED_AT,
                                             id
                                             ])
        conn.commit()
        flash("User updated successfully!", 'success')
        return redirect(url_for('auth.users'))

        
    return render_template('auth/update.html', user=user)



@bp.route('/login', methods=('GET', 'POST'))
def login():
    """Log in a registered user by adding the user id to the session."""
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
       
        conn = get_db()
        db = conn.cursor()
        error = None
        user = db.execute("SELECT * FROM REM_USERS WHERE USERNAME = :USERNAME",
				[username]).fetchone()
        if user is None:
            error = 'Incorrect username.'
        elif not check_password_hash(user[10], password):
            error = 'Incorrect password.'

        if error is None:
            # store the user id in a new session and return to the index
            session.clear()
            session['user_id'] = user[11]
        if(user[6]=="Employee"):
            #return redirect(url_for('points.plists'))
            return redirect(url_for('points.dashboard'))
        else:
             flash(error, 'error')
             return redirect(url_for('auth.users'))
  
             

    return render_template('auth/login.html')


@bp.route('/logout')
def logout():
    """Clear the current session, including the stored user id."""
    session.clear()
    return redirect(url_for('index'))
