import cx_Oracle

import click
from flask import current_app, g
from flask.cli import with_appcontext


def get_db():
    """Connect to the application's configured database. The connection
    is unique for each request and will be reused if this is called
    again.
    """
    if 'db' not in g:
        connstr ="kk33882/Triple1234@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(Host=MSB-MSITM.austin.utexas.edu)(Port=1521))(CONNECT_DATA=(SID=ORCL)))"
        conn = cx_Oracle.connect(connstr)
    return conn


def close_db(e=None):
    """If this request connected to the database, close the
    connection.
    """
    db = get_db()

    if db is not None:
        db.close()


def init_db():
    """Clear existing data and create new tables."""
    db = get_db()
    

@click.command('init-db')
@with_appcontext
def init_db_command():
    """Clear existing data and create new tables."""
    init_db()
    click.echo('Initialized the database.')


def init_app(app):
    """Register database functions with the Flask app. This is called by
    the application factory.
    """
    app.teardown_appcontext(close_db)
    app.cli.add_command(init_db_command)
